package com.example.anispark

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import android.content.SharedPreferences

class Likedquotes : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_likedquotes)

        // Enable the Up button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Fetch the liked quotes from SharedPreferences
        val prefs: SharedPreferences = getSharedPreferences("Likedquotes", MODE_PRIVATE)
        val likedQuotesSet = prefs.getStringSet("quotes", setOf()) ?: setOf()

        // Convert the Set to a List for the adapter
        val likedQuotesList = ArrayList(likedQuotesSet)

        // Set up the adapter to display the liked quotes in the ListView
        val listView = findViewById<ListView>(R.id.LikedquotesListView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, likedQuotesList)
        listView.adapter = adapter
    }

    override fun onSupportNavigateUp(): Boolean {
        // This method is called when the Up button is pressed. Just finish the activity.
        finish()
        return true
    }
}

